#!/usr/bin/env python3
"""Bounded operator job: archive, verified restore and INACTIVE drafts. No activation."""
import argparse
from datetime import datetime, timedelta, timezone
import hashlib
import json
import os
from pathlib import Path
import pwd
import resource
import re
import shutil
import subprocess
import sys

os.umask(0o077)
for thread_variable in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS'):
    os.environ[thread_variable]='1'  # operator process only; no trading/learning worker changes
ROOT = Path('/opt/render/project/src')
if not (ROOT/'scripts/production_restart.py').is_file():
    ROOT = Path.cwd()
sys.path.insert(0,str(ROOT))


def load(p):
    return json.loads(Path(p).read_text(encoding='utf-8-sig'))


def save(p,value):
    with Path(p).open('x',encoding='utf-8') as f:
        json.dump(value,f,ensure_ascii=False,indent=2,allow_nan=False)
    Path(p).chmod(0o600)


def command(args,*,env=None,input=None):
    r=subprocess.run([str(a) for a in args],input=input,capture_output=True,env=env,timeout=1800)
    if r.returncode:
        raise RuntimeError('Operator dependency failed: '+Path(str(args[0])).name)
    return r.stdout


def connections(config):
    import psycopg2
    result={}
    try:
        for name,var in config['database_environment_variables'].items():
            result[name]=psycopg2.connect(os.environ[var],connect_timeout=15)
        return result
    except BaseException:
        for c in result.values():c.close()
        raise


def quiescent(config):
    if os.getenv('ENABLE_WEB_BACKGROUND_SERVICES','false').lower() in {'true','yes','1','on'}:
        raise ValueError('Web background workers enabled; no quiescence claim is made')
    cs=connections(config)
    try:
        for c in cs.values():
            c.set_session(readonly=True)
            with c.cursor() as q:
                q.execute("SELECT count(*) FROM pg_stat_activity WHERE datname=current_database() AND pid<>pg_backend_pid() AND state IN ('active','idle in transaction','idle in transaction (aborted)')")
                if q.fetchone()[0]:raise ValueError('Another active/open transaction exists; archive stopped')
            c.rollback()
    finally:
        for c in cs.values():c.rollback();c.close()


def tools(work):
    paths=[work/'pg18-tools/root/usr/lib/postgresql/18/bin',Path('/usr/lib/postgresql/18/bin')]
    found={}
    for name in ('pg_dump','pg_restore','initdb','pg_ctl','postgres'):
        candidate=next((p/name for p in paths if (p/name).is_file()),None)
        candidate=candidate or shutil.which(name)
        if not candidate:raise ValueError('Missing PostgreSQL 18 dependency: '+name)
        candidate=Path(candidate)
        version=command([candidate,'--version']).decode()
        if not __import__('re').search(r'\b18\.',version):raise ValueError('PostgreSQL 18 tools required')
        found[name]=str(candidate)
    return found


def install_environment(work):
    root=work/'pg18-tools'
    if (root/'lib').is_dir():
        os.environ['LD_LIBRARY_PATH']=str(root/'lib')+(':'+os.environ['LD_LIBRARY_PATH'] if os.environ.get('LD_LIBRARY_PATH') else '')
    locales=root/'root/usr/lib/locale'
    if locales.is_dir():os.environ['LOCPATH']=str(locales)+':/usr/lib/locale'


def private_job(path):
    work=Path(path).resolve()
    if work.parent!=Path('/tmp') or not re.fullmatch(r'nok-job-[0-9]{8}T[0-9]{6}Z',work.name):
        raise ValueError('Only a dedicated /tmp/nok-job-TIMESTAMP directory is accepted')
    if not work.is_dir() or work.stat().st_mode & 0o077 or work.stat().st_uid!=os.geteuid():
        raise ValueError('Private, operator-owned 0700 job directory required')
    plan=load(work/'plan.json')
    if plan.get('job_id')!=work.name or plan.get('activation_authorized') is not False:
        raise ValueError('Exact bounded job identity required; activation is excluded')
    return work,plan


def main(args):
    os.chdir(ROOT)
    work,plan=private_job(args.work)
    if ROOT==work or ROOT in work.parents:raise ValueError('Operator files must stay outside repository')
    if args.action=='cleanup':
        install_environment(work)
        if (work/'isolated-pg/postmaster.pid').is_file():
            pg=tools(work)
            subprocess.run([pg['pg_ctl'],'-D',str(work/'isolated-pg'),'-m','fast','-w','stop'],capture_output=True,timeout=60)
        key=work/'archive-key.pem'
        if key.is_file():key.unlink()
        return
    if plan.get('approval_A_already_granted') is not True:raise ValueError('Approval A required')
    if os.getenv('APP_ENVIRONMENT')!='production':raise ValueError('Real production environment required')
    from services import simulation_archive as archive, simulation_restart as restart, production_restart as control
    from services.production_inventory import discover
    from services.production_routing import strategy_settings
    from services.storage_service import get_storage_service
    from services.economic_opening import digest
    from scripts.production_restart import check_inventory
    storage=get_storage_service();control.require_backend(storage)
    for f in restart.CAPITALS:
        if control.selected(f,storage=storage,require_running=False) is not None:
            raise ValueError('A selected NOK period already exists; never switch or reset it')
    for relative,expected in load(work/'source-manifest.json')['core_sources'].items():
        if hashlib.sha256((ROOT/relative).read_bytes()).hexdigest()!=expected:
            raise ValueError('Deployed accounting source differs: '+relative)
    install_environment(work)
    if args.action=='preflight':
        bootstrap=load('/tmp/aksje-nok-start/bootstrap.json')
        inventory=discover(extra_roots=bootstrap.get('extra_roots'))
        for path in inventory['runtime_roots'].values():
            archive._inventory(path)
            source=Path(path).resolve()
            if source==work or source in work.parents or work in source.parents:
                raise ValueError('Job and source trees must be separate')
        config=dict(extra_roots=bootstrap.get('extra_roots',{}),runtime_roots=inventory['runtime_roots'],
            database_environment_variables={'db_'+v.lower():v for v in inventory['database_environment_variables']},
            archive_root=str(work/'archives'),certificate=str(work/'archive-certificate.pem'),
            restore_destination=str(work/'restore'),inventory_ack_sha256=inventory['inventory_sha256'],
            external_stores_reviewed=False,coverage_confirmed=False,
            coverage={c:list(inventory['runtime_roots'])+['db_'+v.lower() for v in inventory['database_environment_variables']] for c in inventory['coverage']})
        for name,variable in bootstrap.get('extra_database_environment_variables',{}).items():
            if name in config['database_environment_variables'] or name in config['runtime_roots'] or not os.getenv(variable):
                raise ValueError('Additional source must have a unique source ID and configured connection')
            config['database_environment_variables'][name]=variable
            for category in config['coverage']:config['coverage'][category].append(name)
        if not config['database_environment_variables']:raise ValueError('Production database missing')
        cs=connections(config);metadata={};total=0
        try:
            for name,c in cs.items():
                c.set_session(readonly=True)
                with c.cursor() as q:
                    q.execute("SELECT current_setting('server_version_num')::int,pg_database_size(current_database()),pg_encoding_to_char(encoding),datcollate,datctype,datlocprovider,COALESCE(to_jsonb(d)->>'datlocale',to_jsonb(d)->>'daticulocale') FROM pg_database d WHERE datname=current_database()")
                    version,size,encoding,collate,ctype,provider,locale=q.fetchone()
                    if not 180000<=version<190000:raise ValueError('This bounded job requires source PostgreSQL 18')
                    q.execute('SELECT extname,extversion FROM pg_extension ORDER BY extname')
                    extensions=dict(q.fetchall())
                    if set(extensions)&{'pg_cron','pg_task','pglogical','timescaledb'}:
                        raise ValueError('Background extension needs explicit isolated restore configuration; do not execute copied jobs')
                    metadata[name]=dict(bytes=size,encoding=encoding,collate=collate,ctype=ctype,provider=provider,locale=locale,extensions=extensions)
                    total+=size
        finally:
            for c in cs.values():c.rollback();c.close()
        free=shutil.disk_usage(work).free
        if free<total*6+2*1024**3:raise ValueError('Insufficient existing scratch space; no resource will be purchased')
        for name in ('archive-certificate.pem','operator-certificate.pem'):
            command(['openssl','x509','-in',work/name,'-noout'])
        if hashlib.sha256((work/'operator-certificate.pem').read_bytes()).hexdigest()!=os.getenv('NOK_APPROVAL_CERT_SHA256'):
            raise ValueError('Uploaded public operator certificate does not match pinned configuration')
        quiescent(config)
        save(work/'inventory.json',inventory);save(work/'config-unconfirmed.json',config);save(work/'source-databases.json',metadata)
        save(work/'preflight-result.json',dict(sources=inventory['runtime_roots'],database_variables=list(config['database_environment_variables'].values()),
            inventory_sha256=inventory['inventory_sha256'],source_bytes=total,scratch_free_bytes=free,
            extensions={name:m['extensions'] for name,m in metadata.items()},
            required_attestation='All relevant Render/retired/external sources included; cron suspended and all writers stopped',
            can_use_existing_web_scratch_for_isolated_restore=True,paid_resource_required=False))
        return
    pg=tools(work)
    if args.action=='archive':
        ack=load(work/'source-attestation.json');inventory=load(work/'inventory.json')
        if ack.get('inventory_sha256')!=inventory['inventory_sha256'] or ack.get('all_sources_reviewed_and_writers_stopped') is not True:
            raise ValueError('Exact complete-source/quiescence attestation required')
        config=load(work/'config-unconfirmed.json');config.update(external_stores_reviewed=True,coverage_confirmed=True)
        check_inventory(config);quiescent(config)
        if command(['openssl','x509','-in',work/'archive-certificate.pem','-pubkey','-noout'])!=command(['openssl','pkey','-in',work/'archive-key.pem','-pubout']):
            raise ValueError('Archive key does not match certificate')
        cs=connections(config)
        try:
            receipt=archive.create_archive(config['archive_root'],runtime_roots=config['runtime_roots'],databases=cs,
                certificate=config['certificate'],coverage=config['coverage'],source_quiesced=True,coverage_confirmed=True,pg_dump_program=pg['pg_dump'])
        finally:
            for c in cs.values():c.close()
        save(work/'config.json',config);save(work/'archive-receipt.json',receipt)
        return
    config=load(work/'config.json');receipt=load(work/'archive-receipt.json');copy=load(work/'windows-copy-proof.json')
    if (copy.get('archive_id')!=receipt['archive_id'] or copy.get('cipher_sha256')!=receipt['cipher_sha256']
        or copy.get('local_decryption_verified') is not True or copy.get('verified_windows_copy') is not True):
        raise ValueError('Verified independent Windows archive copy required before restore/drafts')
    check_inventory(config);quiescent(config)
    metadata=load(work/'source-databases.json')
    cluster=work/'isolated-pg';socket=work/'pgsocket';socket.mkdir(mode=0o700)
    user=pwd.getpwuid(os.getuid()).pw_name
    if os.geteuid()==0:raise ValueError('Isolated database must not run as root')
    command([pg['initdb'],'-D',cluster,'-U',user,'--encoding=UTF8','--locale=C','--auth-local=peer','--auth-host=reject'])
    options=f"-k {socket} -c listen_addresses='' -c unix_socket_permissions=0700 -c shared_buffers=32MB -c maintenance_work_mem=16MB -c max_connections=10 -c max_wal_size=256MB -c autovacuum=off -c archive_mode=off -c max_parallel_workers=0"
    command([pg['pg_ctl'],'-D',cluster,'-l',work/'isolated-pg.log','-o',options,'-w','start'])
    import psycopg2
    from psycopg2 import sql
    from psycopg2.extensions import make_dsn
    try:
        admin=psycopg2.connect(host=str(socket),dbname='postgres',user=user);admin.autocommit=True
        targets={}
        try:
            for i,(name,source) in enumerate(metadata.items()):
                dbname='nok_restore_'+str(i)
                opts=[sql.SQL('TEMPLATE template0'),sql.SQL('ENCODING {}').format(sql.Literal(source['encoding']))]
                if source['provider']=='c':
                    opts.extend([sql.SQL('LC_COLLATE {}').format(sql.Literal(source['collate'])),sql.SQL('LC_CTYPE {}').format(sql.Literal(source['ctype']))])
                elif source['provider']=='i':opts.extend([sql.SQL('LOCALE_PROVIDER icu'),sql.SQL('ICU_LOCALE {}').format(sql.Literal(source['locale']))])
                elif source['provider']=='b':opts.extend([sql.SQL('LOCALE_PROVIDER builtin'),sql.SQL('BUILTIN_LOCALE {}').format(sql.Literal(source['locale']))])
                else:raise ValueError('Unsupported source collation provider')
                with admin.cursor() as q:
                    q.execute(sql.SQL('CREATE DATABASE {} WITH ').format(sql.Identifier(dbname))+sql.SQL(' ').join(opts))
                targets[name]=make_dsn(host=str(socket),dbname=dbname,user=user)
        finally:admin.close()
        review=archive.restore_drill(config['archive_root'],receipt['archive_id'],certificate=config['certificate'],private_key=work/'archive-key.pem',
            destination=config['restore_destination'],database_targets=targets,pg_restore_program=pg['pg_restore'])
        save(work/'restore-result.json',review)
        reviewed=archive.verify_archive(config['archive_root'],receipt['archive_id'],certificate=config['certificate'],private_key=work/'archive-key.pem')
        cs=connections(config)
        try:archive.verify_live_sources(reviewed,databases=cs)
        finally:
            for c in cs.values():c.close()
        accounts={f:dict(capital_nok=capital,settings=strategy_settings(f,storage=storage),cost_policy=None) for f,capital in restart.CAPITALS.items()}
        # No fee or execution evidence is invented merely to generate approvals.
        save(work/'account-settings-for-review.json',accounts)
        period='nok-'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')
        start=(datetime.now(timezone.utc)+timedelta(minutes=30)).isoformat()
        save(work/'preparation-attempt.json',dict(period_id=period,start_at=start,actor=plan['actor'],status='ATTEMPT_NOT_CONFIRMATION'))
        prepared=restart.prepare(period,start_at=start,prepared_by=plan['actor'],archive_root=config['archive_root'],archive_id=receipt['archive_id'],
            certificate=config['certificate'],private_key=work/'archive-key.pem',storage=storage)
        opening_summaries={}
        from services import portfolio_accounting as accounting
        for f,capital in restart.CAPITALS.items():
            doc=prepared['accounts'][f]
            if doc['status']!='DRAFT' or doc['account']['cash']!=capital or doc['account']['positions'] or doc['account']['trades']:
                raise ValueError('Unexpected opening; no activation attempted')
            if control.selected(f,storage=storage,require_running=False) is not None:raise ValueError('Unexpected selected route')
            summary=accounting.report(f,storage=restart.AccountStorage(period,storage),at=datetime.fromisoformat(start))['new_period']
            if (summary['verification']['verified_nav']!=capital or summary['realized_pnl_nok']!=0 or summary['unrealized_pnl_nok']!=0):
                raise ValueError('Opening NAV/PnL does not reconcile')
            opening_summaries[f]=dict(status=doc['status'],cash_nok=summary['cash_nok'],opening_nav_nok=summary['verification']['verified_nav'],
                positions=0,realized_pnl_nok=summary['realized_pnl_nok'],unrealized_pnl_nok=summary['unrealized_pnl_nok'])
        save(work/'prepared.json',prepared)
        cs=connections(config)
        try:archive.verify_live_sources(reviewed,databases=cs,ignore_period=period)
        finally:
            for c in cs.values():c.close()
        save(work/'final-result.json',dict(status='ARCHIVE_RESTORED_AND_THREE_INACTIVE_DRAFTS_PREPARED',period_id=period,start_at=start,
            capitals_nok=restart.CAPITALS,opening_summaries=opening_summaries,archive_id=receipt['archive_id'],restore_review_sha256=review['review_sha256'],
            independent_windows_copy_verified=True,old_positions_transferred=False,learning_reset=False,strategies_changed=False,
            accounts_activated=False,approval_B_ready=False,
            remaining_before_B=['Document actual cost policies; none assumed','Verify actual completed strategy inputs and fresh live price/FX evidence','Prepare exact signed grants using a private operator key that has not been shared in chat']))
    finally:
        subprocess.run([pg['pg_ctl'],'-D',str(cluster),'-m','fast','-w','stop'],capture_output=True,timeout=60)
        key=work/'archive-key.pem'
        if key.is_file():key.unlink()  # only the task's temporary copy; PC original remains


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action',choices=['preflight','archive','restore-drafts','cleanup'])
    parser.add_argument('--work',required=True);args=parser.parse_args()
    # Bound operator memory on the existing web plan; never exhaust the whole pod.
    resource.setrlimit(resource.RLIMIT_AS,(1152*1024**2,1152*1024**2))
    try:
        main(args)
        print('Completed '+args.action+'; no activation performed.')
    except Exception as error:
        try:
            work,_=private_job(args.work)
            result=work/('STOPPED-'+args.action+'.json')
            if not result.exists():save(result,dict(status='STOPPED',stage=args.action,error_type=type(error).__name__,reason=str(error) if isinstance(error,(ValueError,RuntimeError)) else 'Inspect private operator context',accounts_activated=False))
        except Exception:pass
        print('STOPPED '+args.action+'; inspect private STOPPED receipt. No automatic fallback.',file=sys.stderr)
        raise SystemExit(1)
