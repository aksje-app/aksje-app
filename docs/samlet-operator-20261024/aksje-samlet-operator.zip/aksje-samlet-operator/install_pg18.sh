#!/usr/bin/env bash
# Private PostgreSQL 18 client/server for an isolated restore; no paid Render resource, no sudo.
set -euo pipefail
umask 077
: "${NOK_WORK:?Set NOK_WORK to the private operator directory first}"
pg_tools="$NOK_WORK/pg18-tools"
mkdir -m 700 "$pg_tools"
for tool in curl gpg apt-get apt-cache dpkg-deb ldd; do command -v "$tool" >/dev/null; done
pg_codename=$(python -c 'import platform; print(platform.freedesktop_os_release()["VERSION_CODENAME"])')
pg_arch=$(dpkg --print-architecture)
mkdir -p "$pg_tools/lists/partial" "$pg_tools/cache/archives/partial" "$pg_tools/packages" "$pg_tools/root" "$pg_tools/lib" "$pg_tools/gnupg"
curl --fail --silent --show-error --proto '=https' --tlsv1.2 https://www.postgresql.org/media/keys/ACCC4CF8.asc -o "$pg_tools/pgdg.asc"
pg_fingerprint=$(gpg --homedir "$pg_tools/gnupg" --batch --show-keys --with-colons "$pg_tools/pgdg.asc" 2>/dev/null | awk -F: '$1=="fpr" {print $10;exit}')
test "$pg_fingerprint" = B97B0AFCAA1A47F044F244A07FCC7D46ACCC4CF8
gpg --homedir "$pg_tools/gnupg" --batch --dearmor --output "$pg_tools/pgdg.gpg" "$pg_tools/pgdg.asc"
echo "deb [arch=$pg_arch signed-by=$pg_tools/pgdg.gpg] https://apt.postgresql.org/pub/repos/apt $pg_codename-pgdg main" > "$pg_tools/pgdg.list"
pg_options=(-o "Dir::Etc::sourcelist=$pg_tools/pgdg.list" -o 'Dir::Etc::sourceparts=-' -o "Dir::State::lists=$pg_tools/lists" -o "Dir::Cache::archives=$pg_tools/cache/archives" -o 'Dir::State::status=/var/lib/dpkg/status')
# The PGDG repository supplies libpq/client; retain the system's signed sources
# for resolving ordinary Debian/Ubuntu runtime dependencies.
pg_sources="$pg_tools/system-sources"
mkdir "$pg_sources"
if test -f /etc/apt/sources.list; then cp /etc/apt/sources.list "$pg_sources/system.list"; fi
if test -d /etc/apt/sources.list.d; then cp -a /etc/apt/sources.list.d/. "$pg_sources/"; fi
pg_options[3]="Dir::Etc::sourceparts=$pg_sources"
apt-get "${pg_options[@]}" update
pg_targets=(postgresql-18 postgresql-client-18 libpq5 locales-all)
if python - "$NOK_WORK/preflight-result.json" <<'PY_VECTOR'
import json,sys
p=json.load(open(sys.argv[1]))
raise SystemExit(0 if any('vector' in extensions for extensions in p['extensions'].values()) else 1)
PY_VECTOR
then pg_targets+=(postgresql-18-pgvector); fi
apt-cache "${pg_options[@]}" depends --recurse --no-recommends --no-suggests --no-conflicts --no-breaks --no-replaces --no-enhances "${pg_targets[@]}" |
  awk '/^[a-zA-Z0-9][a-zA-Z0-9+.:_-]*$/ {print $1}' | sort -u > "$pg_tools/package-names.txt"
test -s "$pg_tools/package-names.txt"
cd "$pg_tools/packages"
while IFS= read -r pg_package; do
  pg_candidate=$(apt-cache "${pg_options[@]}" policy "$pg_package" | awk '/Candidate:/ {print $2;exit}')
  if test -n "$pg_candidate" && test "$pg_candidate" != '(none)'; then
    apt-get "${pg_options[@]}" download "$pg_package"
  fi
done < "$pg_tools/package-names.txt"
for pg_package in ./*.deb; do dpkg-deb --extract "$pg_package" "$pg_tools/root"; done
# Use packaged client libraries, but retain the running OS's libc and loader.
python - "$pg_tools" <<'PY'
from pathlib import Path
import shutil,sys
r=Path(sys.argv[1])
excluded=('libc.so','libpthread.so','libdl.so','librt.so','libm.so','libresolv.so','libutil.so','libanl.so','ld-linux','libnss_','libBrokenLocale.so','libthread_db.so')
for p in (r/'root').rglob('*.so*'):
    if p.is_file() and not p.name.startswith(excluded):
        target=r/'lib'/p.name
        if not target.exists():shutil.copyfile(p.resolve(),target)
PY
export LD_LIBRARY_PATH="$pg_tools/lib${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
export PATH="$pg_tools/root/usr/lib/postgresql/18/bin:$PATH"
ldd "$pg_tools/root/usr/lib/postgresql/18/bin/pg_dump" > "$pg_tools/ldd.txt"
if grep -q 'not found' "$pg_tools/ldd.txt"; then echo 'Missing client libraries; stop before production maintenance.' >&2; exit 1; fi
pg_dump --version
pg_restore --version
printf 'export PATH=%q:$PATH\nexport LD_LIBRARY_PATH=%q${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}\n' "$pg_tools/root/usr/lib/postgresql/18/bin" "$pg_tools/lib" > "$pg_tools/use.sh"
echo 'Isolated PostgreSQL tools installed privately. Source "$NOK_WORK/pg18-tools/use.sh" in each new shell.'
