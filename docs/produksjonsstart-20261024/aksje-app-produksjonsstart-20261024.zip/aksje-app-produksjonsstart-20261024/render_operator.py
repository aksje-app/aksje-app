#!/usr/bin/env python3
"""Operator-file helpers; calls no activation/trading API. Run from repo root."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tarfile

sys.path.insert(0, str(Path.cwd()))
os.umask(0o077)
FAMILIES = {'paper': 100000, 'autonomy': 500000, 'super_portfolio': 1000000}


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def write(path, value):
    with Path(path).open('x', encoding='utf-8') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)
    Path(path).chmod(0o600)


def confirm(text):
    if input('Skriv nøyaktig: ' + text + '\n> ') != text:
        raise SystemExit('Stoppet uten godkjenning.')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=['configure', 'requests', 'check-opening', 'check-jobs', 'export-json', 'catalog', 'stage-pack', 'stage-unpack', 'source-identities'])
    parser.add_argument('--work', required=True)
    parser.add_argument('--family', choices=FAMILIES)
    parser.add_argument('--key')
    parser.add_argument('--pointer', default='')
    parser.add_argument('--output')
    parser.add_argument('--input')
    parser.add_argument('--label')
    args = parser.parse_args()
    work = Path(args.work).resolve()
    assert work.is_dir() and not (work.stat().st_mode & 0o077), 'Private 0700 folder required'
    assert os.getenv('APP_ENVIRONMENT') == 'production', 'Use actual production environment'
    from services.economic_opening import digest
    if args.action=='source-identities':
        import psycopg2
        bootstrap=read(work/'bootstrap.json')
        variables=set(('DATABASE_URL','AUTH_DATABASE_URL','POSTGRES_URL','RENDER_DATABASE_URL'))
        variables.update(bootstrap.get('extra_database_environment_variables',{}).values())
        result={}
        for variable in sorted(variables):
            if not os.getenv(variable):continue
            conn=psycopg2.connect(os.environ[variable],connect_timeout=10)
            try:
                conn.set_session(readonly=True)
                with conn.cursor() as cur:
                    cur.execute('SELECT current_database(),inet_server_addr()::text,inet_server_port(),current_setting(\'server_version\')')
                    row=cur.fetchone()
                result[variable]=dict(database_identity_sha256=digest(list(row[:3])),server_version=row[3])
            finally:conn.rollback();conn.close()
        assert args.output and result
        write(args.output,result)
        print('Private databaseidentiteter skrevet; ingen DSN/passord skrevet.')
    elif args.action in {'stage-pack','stage-unpack'}:
        from services.simulation_archive import _inventory, sha
        if args.action=='stage-pack':
            inventory=read(args.input)
            roots=inventory['runtime_roots']
            before={name:_inventory(path) for name,path in roots.items()}
            assert roots and args.output
            with tarfile.open(args.output,'x:gz') as archive:
                for name,path in roots.items():
                    source=Path(path)
                    for relative in before[name]:
                        archive.add(source if source.is_file() else source/relative,arcname=name+'/'+relative,recursive=False)
            assert before=={name:_inventory(path) for name,path in roots.items()}, 'Source changed; do not use package'
            write(args.output+'.sources.json',dict(original_roots=roots,files=before,sha256=sha(args.output)))
            print('Stagingpakke SHA256:',sha(args.output))
        else:
            import re
            assert args.input and args.label and re.fullmatch(r'[A-Za-z0-9_]+',args.label)
            package=Path(args.input);proof=read(str(package)+'.sources.json')
            assert sha(package)==proof['sha256'],'Transfer checksum mismatch'
            dest=work/'staged'/args.label;dest.mkdir(mode=0o700)
            with tarfile.open(package,'r:gz') as archive:
                members=archive.getmembers()
                assert all(m.isfile() and not m.name.startswith('/') and '..' not in Path(m.name).parts for m in members)
                assert len({m.name for m in members})==len(members)
                assert {m.name for m in members}=={name+'/'+r for name,files in proof['files'].items() for r in files}
                archive.extractall(dest,filter='data')
            for name,files in proof['files'].items():
                (dest/name).mkdir(mode=0o700,exist_ok=True)
                assert _inventory(dest/name)==files
            write(dest/'original-sources.json',proof)
            bootstrap=read(work/'bootstrap.json')
            bootstrap.setdefault('extra_roots',{})[args.label+'_files']=str(dest)
            # Only an operator file; preserve the previous bootstrap as evidence.
            old=work/('bootstrap-before-'+args.label+'.json')
            assert not old.exists();(work/'bootstrap.json').rename(old)
            write(work/'bootstrap.json',bootstrap)
            print('Overføring kontrollert og deklarert i bootstrap.json; ingen appdata endret.')
    elif args.action == 'configure':
        inventory = read(work / 'inventory-final.json')
        accounts = read(work / 'account-settings.json')
        bootstrap = read(work / 'bootstrap.json')
        mapping = {}
        sources={'db_'+v.lower():v for v in inventory['database_environment_variables']}
        for source,variable in bootstrap.get('extra_database_environment_variables',{}).items():
            assert source not in sources and os.getenv(variable), 'Extra source must have a unique ID and configured private connection'
            sources[source]=variable
        for source,variable in sources.items():
            target = 'NOK_RESTORE_' + variable
            assert os.getenv(target), 'Missing private Render environment variable: ' + target
            mapping[source] = target
        assert mapping, 'No production database sources discovered'
        for family, capital in FAMILIES.items():
            assert accounts[family]['capital_nok'] == capital
            print('\nModellkostnader i NOK per utført handel:', family)
            from services.economic_ledger import number
            components = {}
            for component in ('brokerage_nok', 'fx_cost_nok', 'other_nok'):
                raw = input(component + ' (ingen standardverdi): ').strip()
                value = number(raw)
                assert value >= 0
                components[component] = value
            source = input('Dokumentert kilde/begrunnelse for modellen, også eventuell nullkostnad: ').strip()
            assert source
            accounts[family]['cost_policy'] = dict(components_per_fill=components, source_ref=source)
        print('Gjennomgå inventory-final.json, alle andre tjenesters inventar og staging-kontrollsummer først.')
        confirm('ALLE KILDER ER KONTROLLERT ' + inventory['inventory_sha256'])
        config = dict(extra_roots=bootstrap.get('extra_roots', {}), runtime_roots=inventory['runtime_roots'],
            database_environment_variables=sources,
            restore_database_environment_variables=mapping, archive_root=str(work / 'archives'),
            certificate='/etc/secrets/nok-archive.pem', restore_destination=str(work / 'restore'),
            inventory_ack_sha256=inventory['inventory_sha256'], external_stores_reviewed=True,
            coverage_confirmed=True, accounts=accounts,
            coverage={category:list(inventory['runtime_roots'])+list(mapping) for category in inventory['coverage']})
        from scripts.production_restart import check_inventory
        check_inventory(config)
        write(work / 'config.json', config)
        print('Privat config.json opprettet; ingen konto eller rute endret.')
    elif args.action == 'requests':
        config = read(work / 'config.json')
        launch = read(work / 'launch.json')
        at = datetime.now(timezone.utc).isoformat()
        assert datetime.fromisoformat(launch['start_at']) <= datetime.now(timezone.utc), 'T0 not reached'
        summary = []
        canonical = work / 'canonical'; canonical.mkdir(mode=0o700)
        for family in FAMILIES:
            request = work / (family + '-request.json')
            subprocess.run([sys.executable, 'scripts/production_restart.py', 'request', '--config',str(work/'config.json'),
                '--period',launch['period_id'],'--family',family,'--actor',launch['actor'],
                '--approval-ref',launch['approval_ref'],'--at',at,'--output',str(request)], check=True)
            p = read(request)
            raw = json.dumps(p,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
            with (canonical / (family + '.bin')).open('xb') as stream: stream.write(raw)
            assert hashlib.sha256(raw).hexdigest() == digest(p)
            summary.append(dict(family=family,capital_nok=p['capital_nok'],environment=p['environment'],
                deployment_id=p['deployment_id'],period_id=p['period_id'],start_at=p['start_at'],
                approved_by=p['approved_by'],approval_ref=p['approval_ref'],opening_sha256=p['opening_sha256'],
                archive=p['archive'],strategy_policy=p['strategy_policy'],cost_policy=p['cost_policy'],request_sha256=digest(p)))
        write(work / 'approval-summary.json', summary)
        print('Tre forespørsler skrevet. Ikke signert eller aktivert. Fullt innhold i *-request.json.')
    elif args.action in {'check-opening','check-jobs'}:
        from services import production_restart as control, simulation_restart as restart
        from services.storage_service import get_storage_service
        storage=get_storage_service();control.require_backend(storage)
        launch=read(work/'launch.json');scoped=restart.AccountStorage(launch['period_id'],storage)
        from services import portfolio_accounting as ledger
        result={}
        for family,capital in FAMILIES.items():
            chosen=control.selected(family,storage=storage,require_running=True)
            assert chosen and chosen['pointer']['period_id']==launch['period_id']
            doc=chosen['bundle']['accounts'][family];ledger.verify(doc)
            report=ledger.report(family,storage=scoped);period=report['new_period']
            assert period and period['verification']['verified_nav'] is not None, 'NAV unverified'
            jobs=[e['payload'] for e in doc['events'] if e['kind']=='STRATEGY_RUN']
            if args.action=='check-opening':
                assert not jobs and not period['positions'] and not period['trades']
                assert period['cash_nok']==capital and period['verification']['verified_nav']==capital
                assert period['realized_pnl_nok']==0 and period['unrealized_pnl_nok']==0
            else:
                assert jobs, 'Ingen finansiell jobbkvittering ennå for '+family
                assert all(j['family']==family and j['period_id']==launch['period_id'] for j in jobs)
            result[family]=dict(status=report['status'],cash_nok=period['cash_nok'],nav_nok=period['verification']['verified_nav'],
                positions=period['positions'],realized_pnl_nok=period['realized_pnl_nok'],unrealized_pnl_nok=period['unrealized_pnl_nok'],
                job_count=len(jobs),first_job=jobs[0] if jobs else None,report=report)
        assert args.output, 'New private --output required'
        write(args.output,result)
        print('Kontroll bestått; privat rapport skrevet. Ingen handler utført av kontrollen.')
    else:
        assert args.output, '--output required'
        import psycopg2
        conn=psycopg2.connect(os.environ['DATABASE_URL'],connect_timeout=10)
        try:
            conn.set_session(readonly=True)
            if args.action=='catalog':
                with conn.cursor() as cur:
                    cur.execute("SELECT name,octet_length(payload::text) FROM app_kv_store WHERE name ~ '(pipeline|candidate|scan|technical|market_snapshot|strategy_run|nok_preparation)' ORDER BY name")
                    rows=[dict(key=name,bytes=size) for name,size in cur.fetchall()]
                write(args.output,rows)
                print('Skrivebeskyttet kildekatalog lagret privat; ingen automatisk kandidatvalidering.')
                return
            assert args.key, '--key required'
            with conn.cursor() as cur:
                cur.execute('SELECT payload FROM app_kv_store WHERE name=%s',(args.key,))
                row=cur.fetchone();assert row, 'Ingen slik lagret kilde'
            value=json.loads(row[0]) if isinstance(row[0],str) else row[0]
            original=value
            for part in args.pointer.strip('/').split('/') if args.pointer else []:
                part=part.replace('~1','/').replace('~0','~')
                value=value[int(part)] if isinstance(value,list) else value[part]
            assert value, 'Empty inputs cannot verify candidate coverage'
            write(args.output,value)
            write(str(args.output)+'.source.json',dict(source_key=args.key,pointer=args.pointer,source_sha256=digest(original),
                exported_sha256=digest(value),at=datetime.now(timezone.utc).isoformat(),semantic_completeness_requires_operator_review=True))
        finally:conn.rollback();conn.close()
        print('Eksakte lagrede input eksportert, uten syntetiske signaler eller handler.')


if __name__=='__main__':
    main()
